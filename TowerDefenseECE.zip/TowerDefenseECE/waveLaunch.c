#include "header.h"

void waveLaunch(int wave, t_acteur top[22], t_acteur mid [22], t_acteur bot[22])
{
    int i=0;



    if (wave<=5)        //si vague inferieure ou egale � 5, 5 ennemis de lvl equivaut a la vague (3 cac 2 distance)
    {
        for(i=0; i<5; i++)
        {
            top[i]=setupActeur(wave, top[i]);
            bot[i]=setupActeur(wave, bot[i]);
            mid[i]=setupActeur(wave, mid[i]);
        }
    }

    else if (wave<=10)       //si vague inferieure ou egale � 10, 10 ennemis de lvl equivalent a la vague (5 cac 5 distance)
    {
        for(i=0; i<10; i++)
        {
            top[i]=setupActeur(wave, top[i]);
            bot[i]=setupActeur(wave, bot[i]);
            mid[i]=setupActeur(wave, mid[i]);
        }


    }


    else                    //au dela de la vague 10, les vagues sont de 15 ennemis de lvl equivalent a la vague (7 cac 7 distance 1 hero)
    {
        for(i=0; i<15; i++)
        {
            top[i]=setupActeur(wave, top[i]);
            bot[i]=setupActeur(wave, bot[i]);
            mid[i]=setupActeur(wave, mid[i]);
        }

    }
}
