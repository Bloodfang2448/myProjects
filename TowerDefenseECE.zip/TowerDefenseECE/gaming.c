#include "header.h"

void gaming(int faction, int niveau, int musicON, int sfxON)
{
    int finish=0,tour=0, tourBis=0, wave=1, compteur=0, pause=0, victory=0, checkwave=1, gold=10, selecBarracks=0, maximum=0;

    t_acteur topLane[22];
    t_acteur midLane[22];
    t_acteur botLane[22];
    t_acteur mines[5];



    MIDI* human1 = load_midi("musique/Human1gm.mid");
    MIDI* human2 = load_midi("musique/Human2gm.mid");
    MIDI* human3 = load_midi("musique/Human3gm.mid");
    MIDI* human4 = load_midi("musique/Human4gm.mid");
    MIDI* orc1 = load_midi("musique/Orc1gm.mid");
    MIDI* orc2 = load_midi("musique/Orc2gm.mid");
    MIDI* orc3 = load_midi("musique/Orc3gm.mid");
    MIDI* orc4 = load_midi("musique/Orc4gm.mid");


    BITMAP* terrain=load_bitmap("terrain.bmp", NULL);
    BITMAP* buffer=create_bitmap(SCREEN_W, SCREEN_H);
    BITMAP* victoire=load_bitmap("menus/victoire.bmp",NULL);
    BITMAP* defaite=load_bitmap("menus/defaite.bmp",NULL);





    if ((faction==0)&&(musicON==1))
    {
        if (niveau==1)
        {
            play_midi(human1, 1);
        }
        if (niveau==2)
        {
            play_midi(human2, 1);

        }
        if (niveau==3)
        {
            play_midi(human3, 1);
        }
        if (niveau==4)
        {
            play_midi(human4, 1);
        }
    }

    if ((faction==1)&&(musicON==1))
    {
        if (niveau==1)
        {
            play_midi(orc1, 1);
        }
        if (niveau==2)
        {
            play_midi(orc2, 1);

        }
        if (niveau==3)
        {
            play_midi(orc3, 3);
        }
        if (niveau==4)
        {
            play_midi(orc4, 1);
        }
    }

    setupLane(topLane, 1);
    setupLane(midLane, 2);
    setupLane(botLane, 3);
    setupMines(mines);
    setupSprite(topLane,faction);
    setupSprite(midLane,faction);
    setupSprite(botLane,faction);
    waveLaunch(wave,topLane,midLane,botLane);


    while (finish==0)
    {
        afficherTout(buffer,terrain, topLane,midLane,botLane,mines,gold,wave,tour,tourBis);

        checkwave=0;

        if(wave<=5)
        {
            maximum=5;
            for(compteur=0; compteur<5; compteur++)           //verification des acteurs
            {
                if((topLane[compteur].pv>0) || (midLane[compteur].pv>0) || (botLane[compteur].pv>0)) //si au moins un ennemi en vie
                {
                    checkwave++;
                }

            }
        }

        else if(wave<=10)
        {
            maximum=10;
            for(compteur=0; compteur<10; compteur++)           //verification des acteurs
            {
                if((topLane[compteur].pv>0) || (midLane[compteur].pv>0) || (botLane[compteur].pv>0)) //si au moins un ennemi en vie
                {
                    checkwave++;
                }
            }
        }

        else if(wave>10)
        {
            maximum=15;
            for(compteur=0; compteur<15; compteur++)           //verification des acteurs
            {
                if((topLane[compteur].pv>0) || (midLane[compteur].pv>0) || (botLane[compteur].pv>0)) //si au moins un ennemi en vie
                {
                    checkwave++;
                }


            }
        }




        if (checkwave==0)                        //lancer prochaine vague
        {
            wave++;
            waveLaunch(wave, topLane, midLane, botLane);
            checkwave=0;

        }

//////////////////
        for (compteur=0; compteur<maximum; compteur++)
        {
        if((topLane[compteur].abscisse>=720)||(midLane[compteur].abscisse>=720) || (botLane[compteur].abscisse>=720))      //condition de fin : d�faite par avancee ennemie
                {
                    victory=0;
                    finish=1;
                }

        }



        if((wave==((niveau*5)+1))&&(niveau!=4))        //condition de fin : victoire par vague
        {
            finish=1;
            victory=1;
        }


        if(key[KEY_ENTER])  //mettre en pause
        {
            pause=1;
        }

        while(pause==1)     //mode pause en pause
        {
            if(key[KEY_ENTER])
            {
                pause=0;
            }

            if(key[KEY_ESC])
            {
                victory=0;
                finish=1;
                pause=0;
            }
        }


        if( (mouse_b&1) && (mouse_x<320) && (mouse_x>290) && (mouse_y>490) && (mouse_y<522) && (gold>=5*(mines[0].lvl)))   //si click fleche mine et assez or, upgrade mine correspondante
        {
            mines[0].lvl++;
            gold-=(5*(mines[0].lvl));
        }

        if( (mouse_b&1) && (mouse_x<380) && (mouse_x>355) && (mouse_y>490) && (mouse_y<522) && (gold>=5*(mines[1].lvl)) )
        {
            mines[1].lvl++;
            gold-=(5*(mines[1].lvl));
        }

        if( (mouse_b&1) && (mouse_x<351) && (mouse_x>324) && (mouse_y>525) && (mouse_y<558) && (gold>=5*(mines[2].lvl)))
        {
            mines[2].lvl++;
            gold-=(5*(mines[2].lvl));
        }

        if( (mouse_b&1) && (mouse_x<316) && (mouse_x>288) && (mouse_y>562) && (mouse_y<597) && (gold>=5*(mines[3].lvl)) )
        {
            mines[3].lvl++;
            gold-=(5*(mines[3].lvl));
        }

        if( (mouse_b&1) && (mouse_x<382) && (mouse_x>354) && (mouse_y>562) && (mouse_y<597) && (gold>=5*(mines[4].lvl)) )
        {
            mines[4].lvl++;
            gold-=(5*(mines[4].lvl));
        }



        //si click fleche tour, upgrade tour correspondante

        if( (mouse_b&1) && (mouse_y<515) && (mouse_y>480) && (mouse_x>418) && (mouse_x<446) && (gold>=(5*(topLane[20].lvl))) )
        {
            gold-=(5*(topLane[20].lvl));
            topLane[20].lvl++;
            topLane[20].pv=(50+(25*(topLane[20].lvl-1)));

        }

        if( (mouse_b&1) && (mouse_y<515) && (mouse_y>480) && (mouse_x>470) && (mouse_x<500) && (gold>=(5*(topLane[20].lvl))) )
        {
            gold-=(5*(midLane[20].lvl));
            midLane[20].lvl++;
            midLane[20].pv=(50+(25*(midLane[20].lvl-1)));

        }

        if( (mouse_b&1) && (mouse_y<515) && (mouse_y>480) && (mouse_x>520) && (mouse_x<550) && (gold>=(5*(topLane[20].lvl))) )
        {
            gold-=(5*(midLane[20].lvl));
            botLane[20].lvl++;
            botLane[20].pv=(50+(25*(botLane[20].lvl-1)));

        }


        //si click sur barraquement du haut, selecBarracks=1
        //------------------------------mid---------------=2
        //------------------------------bas---------------=3

        if ((mouse_b&1) && (mouse_x>653) && (mouse_x<716) && (mouse_y>5) && (mouse_y<65))
        {
            selecBarracks=1;
        }

        if ((mouse_b&1) && (mouse_x>653) && (mouse_x<716) && (mouse_y>155) && (mouse_y<210))
        {
            selecBarracks=2;
        }

        if ((mouse_b&1) && (mouse_x>653) && (mouse_x<716) && (mouse_y>305) && (mouse_y<365))
        {
            selecBarracks=3;
        }


        //si click sur hexagone et assez or et selecBarracks different de 0
        //perd or, switch barrack
        //setupActeur troupe cac sur la lane correspondante et remettre selecBarracks a 0

        if ((mouse_b&1) && (mouse_x>430) && (mouse_x<467) && (mouse_y>557) && (mouse_y<598) && (selecBarracks!=0) && (gold>=10))
        {
            switch (selecBarracks)
            {
            case 1:
                if (topLane[15].pv==0)
                {
                    topLane[15]=setupActeur(wave, topLane[15]);
                    gold-=10;
                }
                else if (topLane[17].pv==0)
                {
                    topLane[17]=setupActeur(wave, topLane[17]);
                    gold-=10;
                }
                else if (topLane[19].pv==0)
                {
                    topLane[19]=setupActeur(wave, topLane[19]);
                    gold-=10;
                }
                break;

            case 2:
                if (midLane[15].pv==0)
                {
                    midLane[15]=setupActeur(wave, midLane[15]);
                    gold-=10;
                }
                else if (midLane[17].pv==0)
                {
                    midLane[17]=setupActeur(wave, midLane[17]);
                    gold-=10;
                }
                else if (midLane[19].pv==0)
                {
                    midLane[19]=setupActeur(wave, midLane[19]);
                    gold-=10;
                }
                break;

            case 3:
                if (botLane[15].pv==0)
                {
                    botLane[15]=setupActeur(wave, botLane[15]);
                    gold-=10;
                }
                else if (botLane[17].pv==0)
                {
                    botLane[17]=setupActeur(wave, botLane[17]);
                    gold-=10;
                }
                else if (botLane[19].pv==0)
                {
                    botLane[19]=setupActeur(wave, botLane[19]);
                    gold-=10;
                }
                break;

            }
            selecBarracks=0;
        }

        //si click sur �toile et assez or et selecBarracks different de 0
        //perte or, switch barrack
        //setupActeur troupe distance sur la lane correspondante et remettre selecBarracks a 0

        if ((mouse_b&1) && (mouse_x>565) && (mouse_x<625) && (mouse_y>542) && (mouse_y<590) && (selecBarracks!=0) && (gold>=10))
        {
            switch (selecBarracks)
            {
            case 1:
                if (topLane[16].pv==0)
                {
                    topLane[16]=setupActeur(wave, topLane[16]);
                    gold-=10;
                }
                else if (topLane[18].pv==0)
                {
                    topLane[18]=setupActeur(wave, topLane[16]);
                    gold-=10;
                }
                break;

            case 2:
                if (midLane[16].pv==0)
                {
                    midLane[16]=setupActeur(wave, midLane[16]);
                    gold-=10;
                }
                else if (midLane[18].pv==0)
                {
                    midLane[18]=setupActeur(wave, midLane[18]);
                    gold-=10;
                }
                break;

            case 3:
                if (botLane[16].pv==0)
                {
                    botLane[16]=setupActeur(wave, botLane[16]);
                    gold-=10;
                }
                else if (botLane[18].pv==0)
                {
                    botLane[18]=setupActeur(wave, botLane[18]);
                    gold-=10;
                }
                break;

            }
            selecBarracks=0;
        }





        tour++;              //gestion des tours d'action par tour de boucle
        if (tour==51)
            {
                tour=0;

            }
        if (tour%10==0)
        {
            tourBis++;          //gestion des animations, sert de tempo
                if (tourBis==2)
                    {tourBis=0;}
        }
        if(tour==50)     //si mine au tour d'action
        {
            gold+=((mines[0].lvl)+(mines[1].lvl)+(mines[2].lvl)+(mines[3].lvl)+(mines[4].lvl)*2);
        }

        evolutionActeur(topLane,tour,faction,gold);
        evolutionActeur(midLane,tour,faction,gold);
        evolutionActeur(botLane,tour,faction,gold);


        afficherTout(buffer,terrain, topLane,midLane,botLane,mines,gold,wave,tour,tourBis);
        rest(50);
    }

    stop_midi();

    if (victory==1)
    {
        blit(victoire,screen,0,0,0,0,SCREEN_W,SCREEN_H);
        rest(5000);
        launcher(0);
    }


    else
    {
        blit(defaite,screen,0,0,0,0,SCREEN_W,SCREEN_H);
        rest(5000);
        launcher(0);

    }


}
