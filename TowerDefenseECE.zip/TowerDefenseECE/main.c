#include "header.h"

int main()
{

    int nbMenu=0, quitting=0;

    allegro_init();
    install_keyboard();
    install_mouse();
    show_mouse(screen);
    srand(time(NULL));
    install_sound(DIGI_AUTODETECT, MIDI_AUTODETECT, NULL);
    set_color_depth(desktop_color_depth());
    if (set_gfx_mode(GFX_AUTODETECT_WINDOWED, 800, 600, 0, 0) != 0)
    {
        allegro_message("probleme GFX mode");
        allegro_exit();
        exit(EXIT_FAILURE);
    }



        launcher(nbMenu);



    return 0;
}END_OF_MAIN();
