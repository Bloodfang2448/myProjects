var files_dup =
[
    [ "affichertout.c", "affichertout_8c.html", "affichertout_8c" ],
    [ "displays.c", "displays_8c.html", "displays_8c" ],
    [ "evolutionActeur.c", "evolution_acteur_8c.html", "evolution_acteur_8c" ],
    [ "gaming.c", "gaming_8c.html", "gaming_8c" ],
    [ "header.h", "header_8h.html", "header_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "setupActeur.c", "setup_acteur_8c.html", "setup_acteur_8c" ],
    [ "waveLaunch.c", "wave_launch_8c.html", "wave_launch_8c" ]
];