var structacteur =
[
    [ "abscisse", "structacteur.html#adee4e550c947cbb5f034c45463f9d2bb", null ],
    [ "basex", "structacteur.html#ad5edd123d27ed5d70acf75f945108cda", null ],
    [ "basey", "structacteur.html#a45dfd5fd3d2048afff43f69b962c5057", null ],
    [ "camp", "structacteur.html#ac6460e0b6ff5c9bbac97742c19d3e72b", null ],
    [ "dmg", "structacteur.html#aae5cd11bae27cb7df8bca2fd5fee775e", null ],
    [ "lvl", "structacteur.html#a6c7f440bf2fb555abdc789a41c6acf44", null ],
    [ "ordonnee", "structacteur.html#a684781afa758d9eceaa734531506f19b", null ],
    [ "pv", "structacteur.html#af1b58e608320ff939118a2a719ba3e6b", null ],
    [ "sprites", "structacteur.html#a0fca5be7414ae37e803185ec15404ad9", null ],
    [ "target", "structacteur.html#ae8aa5cb4faa95420993aad5d4f2e839f", null ],
    [ "type", "structacteur.html#ac765329451135abec74c45e1897abf26", null ]
];