var setup_acteur_8c =
[
    [ "setupActeur", "setup_acteur_8c.html#a5e8ff1c641343afb7ea23c1eb2133e20", null ],
    [ "setupLane", "setup_acteur_8c.html#ae260109bc7c1dc600568c743e847b729", null ],
    [ "setupMines", "setup_acteur_8c.html#a2868209e3deb83f0f589e7d024e80602", null ],
    [ "setupSprite", "setup_acteur_8c.html#a01492825232896326d3403f62cf887e1", null ]
];