var searchData=
[
  ['setupacteur_21',['setupActeur',['../header_8h.html#a5e8ff1c641343afb7ea23c1eb2133e20',1,'setupActeur(int wave, t_acteur unit):&#160;setupActeur.c'],['../setup_acteur_8c.html#a5e8ff1c641343afb7ea23c1eb2133e20',1,'setupActeur(int wave, t_acteur unit):&#160;setupActeur.c']]],
  ['setupacteur_2ec_22',['setupActeur.c',['../setup_acteur_8c.html',1,'']]],
  ['setuplane_23',['setupLane',['../header_8h.html#ae260109bc7c1dc600568c743e847b729',1,'setupLane(t_acteur tableau[22], int lane):&#160;setupActeur.c'],['../setup_acteur_8c.html#ae260109bc7c1dc600568c743e847b729',1,'setupLane(t_acteur tableau[22], int lane):&#160;setupActeur.c']]],
  ['setupmines_24',['setupMines',['../header_8h.html#a2868209e3deb83f0f589e7d024e80602',1,'setupMines(t_acteur mines[5]):&#160;setupActeur.c'],['../setup_acteur_8c.html#a2868209e3deb83f0f589e7d024e80602',1,'setupMines(t_acteur mines[5]):&#160;setupActeur.c']]],
  ['setupsprite_25',['setupSprite',['../header_8h.html#a01492825232896326d3403f62cf887e1',1,'setupSprite(t_acteur tableau[22], int faction):&#160;setupActeur.c'],['../setup_acteur_8c.html#a01492825232896326d3403f62cf887e1',1,'setupSprite(t_acteur tableau[22], int faction):&#160;setupActeur.c']]],
  ['sprites_26',['sprites',['../structacteur.html#a0fca5be7414ae37e803185ec15404ad9',1,'acteur']]]
];
