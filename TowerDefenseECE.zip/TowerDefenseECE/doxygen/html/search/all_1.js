var searchData=
[
  ['basex_4',['basex',['../structacteur.html#ad5edd123d27ed5d70acf75f945108cda',1,'acteur']]],
  ['basey_5',['basey',['../structacteur.html#a45dfd5fd3d2048afff43f69b962c5057',1,'acteur']]]
];
