var searchData=
[
  ['gaming_2ec_36',['gaming.c',['../gaming_8c.html',1,'']]]
];
