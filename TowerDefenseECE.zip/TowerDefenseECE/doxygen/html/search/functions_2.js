var searchData=
[
  ['gaming_44',['gaming',['../header_8h.html#a62acd51257d166cfa1013309fd8fd9e1',1,'gaming(int faction, int niveau, int musicON, int sfxON):&#160;gaming.c'],['../gaming_8c.html#a62acd51257d166cfa1013309fd8fd9e1',1,'gaming(int faction, int niveau, int musicON, int sfxON):&#160;gaming.c']]]
];
