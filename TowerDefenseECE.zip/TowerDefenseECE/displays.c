#include "header.h"

void launcher (int nbMenu)
{
    show_mouse(screen);
    BITMAP* title = create_bitmap(SCREEN_W, SCREEN_H);
    title = load_bitmap("menus/titlescreen.bmp", NULL);

    BITMAP* menu1 = create_bitmap(SCREEN_W, SCREEN_H);
    menu1 = load_bitmap("menus/menu1.bmp", NULL);

    BITMAP* menu2 = create_bitmap(SCREEN_W, SCREEN_H);
    menu2 = load_bitmap("menus/menu2.bmp", NULL);

    BITMAP* menu3 = create_bitmap(SCREEN_W, SCREEN_H);
    menu3 = load_bitmap("menus/menu3.bmp", NULL);

    BITMAP* menu4 = create_bitmap(SCREEN_W, SCREEN_H);
    menu4 = load_bitmap("menus/menu4.bmp", NULL);

    BITMAP* menu5 = create_bitmap(SCREEN_W, SCREEN_H);
    menu5 = load_bitmap("menus/menu5.bmp", NULL);

    BITMAP* buffer1 = create_bitmap(SCREEN_W, SCREEN_H);

    MIDI* musicmenu = load_midi("musique/Introgm.mid");

    int gameON=0, faction=0, niveau=1, musicON=1, sfxON=1;




while (gameON==0)
{




    if (nbMenu==0)
    {
        blit(title, buffer1, 0,0,0,0,SCREEN_W, SCREEN_H);

            if (key[KEY_ENTER])
        {
            clear(buffer1);
            play_midi(musicmenu, 1);
           nbMenu=1;
        }
    }
//MENU PRINCIPAL
     if (nbMenu==1)
    {
        blit(menu1, buffer1, 0,0,0,0,SCREEN_W, SCREEN_H);

//SELECTION DES MENUS, NAVIGATION

            //ALLER AU MENU DE CREATION DE PARTIE
            if ((mouse_y>180)&&(mouse_y<255)&&(mouse_x>260)&&(mouse_x<530)&&(mouse_b&1))
        {
            clear(buffer1);
           nbMenu=2;
        }

        //ALLER AU MENU AIDE
            if ((mouse_y>265)&&(mouse_y<335)&&(mouse_x>260)&&(mouse_x<530)&&(mouse_b&1))
        {
            clear(buffer1);
           nbMenu=3;
        }

        //ALLER AU MENU OPTIONS
            if ((mouse_y>345)&&(mouse_y<420)&&(mouse_x>260)&&(mouse_x<530)&&(mouse_b&1))
        {
            clear(buffer1);
           nbMenu=4;
        }

        //ALLER AU MENU AUTEURS
        if ((mouse_y>425)&&(mouse_y<500)&&(mouse_x>260)&&(mouse_x<530)&&(mouse_b&1))
        {
            clear(buffer1);
           nbMenu=5;
        }

        //QUITTER LE JEU
        if ((mouse_y>427)&&(mouse_y<500)&&(mouse_x>571)&&(mouse_x<649)&&(mouse_b&1))
        {
            exit(0);
        }
    }

//MENU DE CREATION DE PARTIE
    if (nbMenu==2)
    {
        blit(menu2, buffer1, 0,0,0,0,SCREEN_W, SCREEN_H);
        if (faction==0)
                {blit(menu2, buffer1, 0,0,0,0,SCREEN_W, SCREEN_H);
                textprintf(buffer1,font,450,218,makecol(255,0,0),"Humains");}
        else if(faction==1)
                {blit(menu2, buffer1, 0,0,0,0,SCREEN_W, SCREEN_H);
                textprintf(buffer1,font,450,218,makecol(255,0,0),"Orcs");}
        textprintf(buffer1,font,450,297,makecol(255,0,0),"%d",niveau);


        //CHOIX DE FACTION
        if ((mouse_y>200)&&(mouse_y<255)&&(mouse_x>450)&&(mouse_x<515)&&(mouse_b&1))
        {
           faction++;
           if (faction==2)
            faction=0;



        }

        //CHOIX DE NIVEAU +1
        if ((mouse_y>265)&&(mouse_y<290)&&(mouse_x>500)&&(mouse_x<530)&&(mouse_b&1))
        {
            niveau++;
            if (niveau==5)
                niveau=1;
        }

        //CHOIX DE NIVEAU -1
        if ((mouse_y>300)&&(mouse_y<335)&&(mouse_x>500)&&(mouse_x<530)&&(mouse_b&1))
        {
            niveau--;
            if (niveau==0)
                niveau=4;
        }

        //LANCER LA PARTIE
        if ((mouse_y>345)&&(mouse_y<420)&&(mouse_x>265)&&(mouse_x<530)&&(mouse_b&1))
        {
            gameON=1;
        }

        //RETOUR MENU PRINCIPAL
        if ((mouse_y>428)&&(mouse_y<500)&&(mouse_x>265)&&(mouse_x<530)&&(mouse_b&1))
        {
            clear(buffer1);
            nbMenu=1;
        }

    }

//MENU AIDE
    if (nbMenu==3)
    {
        blit(menu3, buffer1, 0,0,0,0,SCREEN_W, SCREEN_H);

        //RETOUR MENU PRINCIPAL
        if ((mouse_y>430)&&(mouse_y<505)&&(mouse_x>265)&&(mouse_x<530)&&(mouse_b&1))
        {
            rest(100);
            nbMenu=1;
        }
    }

//MENU OPTIONS
    if (nbMenu==4)
    {
        blit(menu4, buffer1,0,0,0,0, SCREEN_W, SCREEN_H);

        //ACTIVER OU DESACTIVER MUSIQUE
        if ((mouse_y>240)&&(mouse_y<270)&&(mouse_x>135)&&(mouse_x<205)&&(mouse_b&1))
        {
            musicON=1;
            play_midi(musicmenu, 1);
        }

        if ((mouse_y>240)&&(mouse_y<270)&&(mouse_x>270)&&(mouse_x<400)&&(mouse_b&1))
        {
            musicON=0;
            stop_midi();

        }

        //ACTIVER OU DESACTIVER SON
        if ((mouse_y>345)&&(mouse_y<370)&&(mouse_x>135)&&(mouse_x<205)&&(mouse_b&1))
        {
            sfxON=1;
        }

        if ((mouse_y>345)&&(mouse_y<370)&&(mouse_x>270)&&(mouse_x<400)&&(mouse_b&1))
        {
            sfxON=0;
        }

        //RETOUR MENU PRINCIPAL
        if ((mouse_y>415)&&(mouse_y<490)&&(mouse_x>265)&&(mouse_x<532)&&(mouse_b&1))
        {

            nbMenu=1;
        }
    }

//MENU AUTEURS
    if(nbMenu==5)
    {
        blit(menu5, buffer1,0,0,0,0, SCREEN_W, SCREEN_H);

        //RETOUR MENU PRINCIPAL
        if ((mouse_y>428)&&(mouse_y<500)&&(mouse_x>265)&&(mouse_x<530)&&(mouse_b&2))
        {

            nbMenu=1;
        }
    }

    blit(buffer1,screen,0,0,0,0,SCREEN_W,SCREEN_H);



}

if (gameON==1)
{
    gaming(faction, niveau, musicON, sfxON);
}


rest(10);

}
