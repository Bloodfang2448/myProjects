#include "header.h"


void setupSprite(t_acteur tableau [22], int faction)
{
    int compteur=0;

    if (faction==0)         //si joueur humain
    {
        for(compteur=0; compteur<22; compteur++)
        {
            if(compteur<15)
            {

                if(compteur==14)
                {
                    tableau[compteur].sprites[0]=load_bitmap("sprites/orcs/hero/run1.bmp",NULL);
                    tableau[compteur].sprites[1]=load_bitmap("sprites/orcs/hero/run2.bmp",NULL);
                    tableau[compteur].sprites[2]=load_bitmap("sprites/orcs/hero/attack.bmp",NULL);
                }
                else if(compteur%2==1)
                {
                    tableau[compteur].sprites[0]=load_bitmap("sprites/orcs/dist/run1.bmp",NULL);
                    tableau[compteur].sprites[1]=load_bitmap("sprites/orcs/dist/run2.bmp",NULL);
                    tableau[compteur].sprites[2]=load_bitmap("sprites/orcs/dist/attack.bmp",NULL);
                }
                else
                {
                    tableau[compteur].sprites[0]=load_bitmap("sprites/orcs/cac/run1.bmp",NULL);
                    tableau[compteur].sprites[1]=load_bitmap("sprites/orcs/cac/run2.bmp",NULL);
                    tableau[compteur].sprites[2]=load_bitmap("sprites/orcs/cac/attack.bmp",NULL);
                }

            }

            else if((compteur<20) && (compteur>=15))
            {

                if(compteur%2==1)
                {
                    tableau[compteur].sprites[0]=load_bitmap("sprites/humans/cac/run1.bmp",NULL);
                    tableau[compteur].sprites[1]=load_bitmap("sprites/humans/cac/run2.bmp",NULL);
                    tableau[compteur].sprites[2]=load_bitmap("sprites/humans/cac/attack.bmp",NULL);
                }
                else
                {
                    tableau[compteur].sprites[0]=load_bitmap("sprites/humans/dist/run1.bmp",NULL);
                    tableau[compteur].sprites[1]=load_bitmap("sprites/humans/dist/run2.bmp",NULL);
                    tableau[compteur].sprites[2]=load_bitmap("sprites/humans/dist/attack.bmp",NULL);
                }
            }
            else if(compteur==20)
            {
                tableau[compteur].sprites[0]=load_bitmap("sprites/humans/tower/tower1.bmp", NULL);
                tableau[compteur].sprites[1]=load_bitmap("sprites/humans/tower/tower2.bmp", NULL);
                tableau[compteur].sprites[2]=load_bitmap("sprites/humans/tower/tower3.bmp", NULL);
            }

            else if(compteur==21)
            {
                tableau[compteur].sprites[0]=load_bitmap("sprites/humans/barracks/barracks.bmp", NULL);
                tableau[compteur].sprites[1]=load_bitmap("sprites/humans/barracks/barracks.bmp", NULL);
                tableau[compteur].sprites[2]=load_bitmap("sprites/humans/barracks/barracks.bmp", NULL);

            }
        }

    }

    else if (faction==1)                //si joueur orc
    {
        for(compteur=0; compteur<22; compteur ++)
        {

            if(compteur<15)
            {

                if(compteur==14)
                {
                    tableau[compteur].sprites[0]=load_bitmap("sprites/humans/hero/run1.bmp",NULL);
                    tableau[compteur].sprites[1]=load_bitmap("sprites/humans/hero/run2.bmp",NULL);
                    tableau[compteur].sprites[2]=load_bitmap("sprites/humans/hero/attack.bmp",NULL);
                }
                else if(compteur%2==1)
                {
                    tableau[compteur].sprites[0]=load_bitmap("sprites/humans/dist/run1.bmp",NULL);
                    tableau[compteur].sprites[1]=load_bitmap("sprites/humans/dist/run2.bmp",NULL);
                    tableau[compteur].sprites[2]=load_bitmap("sprites/humans/dist/attack.bmp",NULL);
                }
                else
                {
                    tableau[compteur].sprites[0]=load_bitmap("sprites/humans/cac/run1.bmp",NULL);
                    tableau[compteur].sprites[1]=load_bitmap("sprites/humans/cac/run2.bmp",NULL);
                    tableau[compteur].sprites[2]=load_bitmap("sprites/humans/cac/attack.bmp",NULL);
                }

            }

            else if(compteur<20)
            {

                if(compteur%2==1)
                {
                    tableau[compteur].sprites[0]=load_bitmap("sprites/orcs/cac/run1.bmp",NULL);
                    tableau[compteur].sprites[1]=load_bitmap("sprites/orcs/cac/run2.bmp",NULL);
                    tableau[compteur].sprites[2]=load_bitmap("sprites/orcs/cac/attack.bmp",NULL);
                }
                else
                {
                    tableau[compteur].sprites[0]=load_bitmap("sprites/orcs/dist/run1.bmp",NULL);
                    tableau[compteur].sprites[1]=load_bitmap("sprites/orcs/dist/run2.bmp",NULL);
                    tableau[compteur].sprites[2]=load_bitmap("sprites/orcs/dist/attack.bmp",NULL);
                }
            }
            else if(compteur==20)
            {
                tableau[compteur].sprites[0]=load_bitmap("sprites/orcs/tower/tower1.bmp", NULL);
                tableau[compteur].sprites[1]=load_bitmap("sprites/orcs/tower/tower2.bmp", NULL);
                tableau[compteur].sprites[2]=load_bitmap("sprites/orcs/tower/tower3.bmp", NULL);
            }

            else if(compteur==21)
            {
                tableau[compteur].sprites[0]=load_bitmap("sprites/orcs/barracks/barracks.bmp", NULL);
                tableau[compteur].sprites[1]=load_bitmap("sprites/orcs/barracks/barracks.bmp", NULL);
                tableau[compteur].sprites[2]=load_bitmap("sprites/orcs/barracks/barracks.bmp", NULL);


            }

        }
    }
}

t_acteur setupActeur(int wave, t_acteur unit)
{

    unit.lvl=wave;
    if(unit.type==4)
    {
        unit.pv=10+(unit.lvl*5);
        unit.dmg=5*unit.lvl;
    }

    if(unit.type==5)
    {
        unit.pv=5+(unit.lvl*5);
        unit.dmg=10*unit.lvl;
    }

    if(unit.type==6)
    {
        unit.pv=20*unit.lvl;
        unit.dmg=20*unit.lvl;
    }

    unit.abscisse=unit.basex;
    unit.ordonnee=unit.basey;
    unit.target=404;

    return unit;
}

void setupLane(t_acteur tableau [22], int lane)
{
    int compteur=0, calcY=0;

    switch (lane)
        {
        case 1:
            calcY=80;
            break;
        case 2:
            calcY=230;
            break;
        case 3:
            calcY=385;
            break;
        }


    for(compteur=0; compteur<22; compteur++)
    {
        if(compteur<15)
        {
            tableau[compteur].camp=1;
            tableau[compteur].basex=rand()%85;
            tableau[compteur].basey=(compteur*4)+calcY;
            tableau[compteur].pv=0;
            tableau[compteur].target=404;

            if(compteur==15)
            {
                tableau[compteur].type=6;
            }
            else if(compteur%2==1)
            {
                tableau[compteur].type=5;
            }
            else
            {
                tableau[compteur].type=4;
            }

        }

        else if((compteur<20) && (compteur>=15))
        {
            tableau[compteur].camp=0;
            tableau[compteur].basex=690;
            tableau[compteur].basey=(compteur)+calcY;
            tableau[compteur].target=404;
            tableau[compteur].pv=0;

            if(compteur%2==1)
            {
                tableau[compteur].type=4;
            }
            else
            {
                tableau[compteur].type=5;
            }
        }

        else if(compteur==20)
        {
            tableau[compteur].type=1;
            tableau[compteur].pv=50;
            tableau[compteur].dmg=10;
            tableau[compteur].lvl=1;
            tableau[compteur].abscisse=530;
            tableau[compteur].ordonnee=calcY;
            tableau[compteur].target=404;
        }

        else if(compteur==21)
        {
            tableau[compteur].type=2;
            tableau[compteur].pv=1;
            tableau[compteur].abscisse=658;
            tableau[compteur].ordonnee=calcY-72;
        }
    }
}


void setupMines(t_acteur mines[5])
{
    int i=0;

    for(i=0; i<5; i++)
    {
        mines[i].lvl=1;
        mines[i].pv=1;
        mines[i].sprites[0]=load_bitmap("sprites/mine.bmp", NULL);
        mines[i].sprites[1]=load_bitmap("sprites/mine.bmp", NULL);
        mines[i].sprites[2]=load_bitmap("sprites/mine.bmp", NULL);
    }
    mines[0].abscisse=73;
    mines[0].ordonnee=6;
    mines[1].abscisse=189;
    mines[1].ordonnee=6;
    mines[2].abscisse=293;
    mines[2].ordonnee=6;
    mines[3].abscisse=405;
    mines[3].ordonnee=6;
    mines[4].abscisse=533;
    mines[4].ordonnee=6;



}

