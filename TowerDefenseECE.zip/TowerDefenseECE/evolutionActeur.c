#include "header.h"



void evolutionActeur(t_acteur tab[22],  int tour,int faction, int gold) //ce sous-programme permet de faire �voluer les acteurs sur le champ de bataille
//(deplacement, �volution des points de vie, mort, attaque)
{
    int i,j,cible, tempo;

    for (i = 0; i < 21; i++)
    {
        cible=tab[i].target;
        if(tab[i].pv>0)         //si en vie
        {
            if(tab[i].type==1)      //si unit� de tour
            {
                if ((cible==404) || (tab[cible].pv<=0))       //si pas de cible
                {
                    for (j=0; j<22; j++)
                    {
                        if ((tab[j].camp==1) && (tab[j].pv>0))
                        {
                            tab[i].target=j;
                        }
                    }
                }

                if (tour==50)                    //si tour d'action
                {
                    tab[cible].pv-=(5*(tab[i].lvl));
                    if (tab[tab[i].target].pv<=0)
                    {
                        gold+=5;
                    }
                }

            }



            if(tab[i].type==4)      //si troupe corps � corps
            {
                if((tab[i].target==404) || (tab[cible].pv<=0))      //si pas de cible
                {
                    if(tab[i].camp==1)      //si ennemi
                    {
                        tab[i].abscisse+=1;
                        for(j=0; j<22; j++)     //ciblage
                        {
                            if((tab[j].camp==0) && (tab[j].abscisse<=tab[i].abscisse+5) && (tab[j].abscisse>=tab[i].abscisse-5) && (tab[j].pv>0))
                            {
                                tab[i].target=j;
                            }
                        }
                    }
                    if(tab[i].camp==0)      //si alli�
                    {
                        tab[i].abscisse-=1;
                        for(j=0; j<22; j++)     //ciblage
                        {
                            if((tab[j].camp==1) && (tab[j].abscisse<=tab[i].abscisse+5) && (tab[j].abscisse>=tab[i].abscisse-5) && (tab[j].pv>0))
                            {
                                tab[i].target=j;
                            }
                        }

                    }

                }

                else if ((tour==50) && (cible!=404))         //si a une cible et tour action, attaquer
                {
                    tab[cible].pv=tab[cible].pv-tab[i].dmg;
                    if((tab[cible].pv<=0) && (tab[i].camp==0))
                    {
                        gold+=5;
                    }
                }

            }

            if(tab[i].type==5)      //si troupe distance
            {
                if((tab[i].target==404) || (tab[cible].pv<=0))     //si pas de cible
                {
                    if(tab[i].camp==1)      //si ennemi
                    {
                        tab[i].abscisse+=1;
                        for(j=0; j<22; j++)     //ciblage
                        {
                            if((tab[j].camp==0) && (tab[j].abscisse<=tab[i].abscisse+20) && (tab[j].abscisse>=tab[i].abscisse-20) && (tab[j].pv>0))
                            {
                                tab[i].target=j;
                            }
                        }
                    }
                    if(tab[i].camp==0)      //si alli�
                    {
                        tab[i].abscisse-=1;
                        for(j=0; j<22; j++)     //ciblage
                        {
                            if((tab[j].camp==1) && (tab[j].abscisse<=tab[i].abscisse+20) && (tab[j].abscisse>=tab[i].abscisse-20) && (tab[j].pv>0))
                            {
                                tab[i].target=j;
                            }
                        }

                    }

                }

                else if (tour==50)          //si a une cible et tour action, attaquer
                {
                    tab[tab[i].target].pv-=tab[i].dmg;
                    tab[i].abscisse=tab[i].abscisse;
                    if((tab[tab[i].target].pv<=0) && (tab[i].camp==0)) //si tue cible et est du cote du joueur
                    {
                        gold+=5;
                    }
                }

            }



        }
    }
}
