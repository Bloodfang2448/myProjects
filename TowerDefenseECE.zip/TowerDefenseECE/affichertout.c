#include "header.h"

/**
*/
void afficherTout(BITMAP* buffer, BITMAP* terrain, t_acteur topLane[22], t_acteur midLane[22], t_acteur botLane[22], t_acteur mines[5], int gold, int wave, int tour, int tourBis)
{
    int i=0, j=0;


    blit(terrain,buffer,0,0,0,0,SCREEN_W, SCREEN_H);
    textprintf(buffer,font,175,480,makecol(255,0,0),"%d",gold);
    textprintf(buffer,font,210,550,makecol(255,0,0),"%d", wave);

    for (i=0; i<5; i++)
    {
        masked_blit(mines[i].sprites[0], buffer,0,0,mines[i].abscisse,mines[i].ordonnee,59,65);
    }

    for(j=0; j<22; j++)
    {
        if (j==20)          //affichage tour
        {
            if(topLane[j].pv>0)
            {
                if(topLane[j].lvl<=3)
                {masked_blit(topLane[j].sprites[0],buffer,0,0,530,75,60,63);}
                else if(topLane[j].lvl<=6)
                {masked_blit(topLane[j].sprites[1],buffer,0,0,530,75,60,63);}
                else
                {masked_blit(topLane[j].sprites[2],buffer,0,0,530,75,60,63);}

            }
            if(midLane[j].pv>0)
            {
                if(midLane[j].lvl<=3)
                {masked_blit(midLane[j].sprites[0],buffer,0,0,530,225,60,63);}
                else if(midLane[j].lvl<=6)
                {masked_blit(midLane[j].sprites[1],buffer,0,0,530,225,60,63);}
                else
                {masked_blit(midLane[j].sprites[2],buffer,0,0,530,225,60,63);}

            }

            if(botLane[j].pv>0)
            {
                if(botLane[j].lvl<=3)
                {masked_blit(botLane[j].sprites[0],buffer,0,0,530,381,60,63);}
                else if(botLane[j].lvl<=6)
                {masked_blit(botLane[j].sprites[1],buffer,0,0,530,381,60,63);}
                else
                {masked_blit(botLane[j].sprites[2],buffer,0,0,530,381,60,63);}

            }
        }

        else if (j==21)          //affichage barracks
        {
            masked_blit(topLane[j].sprites[0], buffer,0,0,topLane[j].abscisse,topLane[j].ordonnee,60,63);
            masked_blit(midLane[j].sprites[0], buffer,0,0,midLane[j].abscisse,midLane[j].ordonnee,60,63);
            masked_blit(midLane[j].sprites[0], buffer,0,0,botLane[j].abscisse,botLane[j].ordonnee,60,63);

        }


        else if(tourBis==0)  //affichage troupe si tour d'animation idle
        {
            if(j<15)        //ennemis
            {
                if(topLane[j].pv>0)
                {
                    draw_sprite(buffer,topLane[j].sprites[0],topLane[j].abscisse,topLane[j].ordonnee);
                }
                if(midLane[j].pv>0)
                {
                    draw_sprite(buffer,midLane[j].sprites[0],midLane[j].abscisse,midLane[j].ordonnee);
                }
                if(botLane[j].pv>0)
                {
                    draw_sprite(buffer,botLane[j].sprites[0],botLane[j].abscisse,botLane[j].ordonnee);
                }
            }

            else if((j>=15) && (j<=19))      //alli�s
            {
                if(topLane[j].pv>0)
                {
                    draw_sprite_h_flip(buffer,topLane[j].sprites[0],topLane[j].abscisse,topLane[j].ordonnee);
                }
                if(midLane[j].pv>0)
                {
                    draw_sprite_h_flip(buffer,midLane[j].sprites[0],midLane[j].abscisse,midLane[j].ordonnee);
                }
                if(botLane[j].pv>0)
                {
                    draw_sprite_h_flip(buffer,botLane[j].sprites[0],botLane[j].abscisse,botLane[j].ordonnee);
                }
            }
        }

        else if(tourBis==1) //affichage troupe si tour d'action
        {
            if(j<15)        //ennemis
            {
                if(topLane[j].pv>0)
                {
                    if(topLane[j].target!=404)
                    {
                        draw_sprite(buffer,topLane[j].sprites[2],topLane[j].abscisse,topLane[j].ordonnee);
                    }
                    else
                    {
                        draw_sprite(buffer,topLane[j].sprites[1],topLane[j].abscisse,topLane[j].ordonnee);
                    }
                }
                if(midLane[j].pv>0)
                {
                    if(midLane[j].target!=404)
                    {
                        draw_sprite(buffer,midLane[j].sprites[2],midLane[j].abscisse,midLane[j].ordonnee);
                    }
                    else
                    {
                        draw_sprite(buffer,midLane[j].sprites[1],midLane[j].abscisse,midLane[j].ordonnee);
                    }
                }
                if(botLane[j].pv>0)
                {
                    if(botLane[j].target!=404)
                    {
                        draw_sprite(buffer,botLane[j].sprites[2],botLane[j].abscisse,botLane[j].ordonnee);
                    }
                    else
                    {
                        draw_sprite(buffer,botLane[j].sprites[1],botLane[j].abscisse,botLane[j].ordonnee);
                    }
                }
            }//end else ...

            else if((j>=15) && (j<=19))      //alli�s
            {
                if(topLane[j].pv>0)
                {
                    if(topLane[j].target!=404)
                    {
                        draw_sprite_h_flip(buffer,topLane[j].sprites[2],topLane[j].abscisse,topLane[j].ordonnee);
                    }
                    else
                    {
                        draw_sprite_h_flip(buffer,topLane[j].sprites[1],topLane[j].abscisse,topLane[j].ordonnee);
                    }
                }
                if(midLane[j].pv>0)
                {
                    if(midLane[j].target!=404)
                    {
                        draw_sprite_h_flip(buffer,midLane[j].sprites[2],midLane[j].abscisse,midLane[j].ordonnee);
                    }
                    else
                    {
                        draw_sprite_h_flip(buffer,midLane[j].sprites[1],midLane[j].abscisse,midLane[j].ordonnee);
                    }
                }
                if(botLane[j].pv>0)
                {
                    if(botLane[j].target!=404)
                    {
                        draw_sprite_h_flip(buffer,botLane[j].sprites[2],botLane[j].abscisse,botLane[j].ordonnee);
                    }
                    else
                    {
                        draw_sprite_h_flip(buffer,botLane[j].sprites[1],botLane[j].abscisse,botLane[j].ordonnee);
                    }
                }
            }
        }


    }
    blit(buffer,screen,0,0,0,0,SCREEN_W,SCREEN_H);

}
