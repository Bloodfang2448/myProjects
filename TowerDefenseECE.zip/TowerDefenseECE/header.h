#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

/**


*/

#include <stdio.h>
#include <stdlib.h>
#include <allegro.h>
#include <time.h>

#define SIZE_WAVE 22
#define SIZE_W 800
#define SIZE_H 600


typedef struct acteur   //d�claration de la structure acteur
{
    int type;           // 1- tour 2-baraquements 3-mine 4-troupe cac 5-troupe distance 6-h�ro ennemi
    int camp;           //faction de l'acteur joueur ou pnj. peu importe le camp choisi par le joueur, il sera attribu� � 0, et l'ennemi � 1
    int abscisse;       //position x de l'acteur
    int basex;          // pos x d'origine
    int ordonnee;       //pos y sur la lane pour plus de visibilite
    int basey;          //pos y d'origine
    int pv;             //point de vie de l'acteur
    int dmg;            //degats de l'acteur
    int lvl;            //niveau de l'acteur
    int target;         //cible de l'acteur correspondant � lane[target], mis � 404 si pas de cible
    BITMAP* sprites [3]; // tableau de sprites
}t_acteur;

void evolutionActeur(t_acteur tab[SIZE_WAVE], int tour,int faction, int gold);
void launcher(int nbMenu);
void gaming(int faction, int niveau, int musicON, int sfxON);
void waveLaunch(int wave, t_acteur top[SIZE_WAVE], t_acteur mid [SIZE_WAVE], t_acteur bot[SIZE_WAVE]);
t_acteur setupActeur(int wave, t_acteur unit);
void setupLane(t_acteur tableau [SIZE_WAVE], int lane);
void setupSprite(t_acteur tableau[SIZE_WAVE], int faction);
void setupMines(t_acteur mines[5]);
void afficherTout(BITMAP* buffer, BITMAP* terrain, t_acteur topLane[SIZE_WAVE], t_acteur midLane[SIZE_WAVE], t_acteur botLane[SIZE_WAVE], t_acteur mines[5], int gold, int wave, int tour, int tourBis);


#endif // HEADER_H_INCLUDED
