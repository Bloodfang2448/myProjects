#include "header.h"

t_sprite* creer_missile2(int x,int y,int type)
{
    t_sprite* missile;
    missile=(t_sprite*)malloc(sizeof(t_sprite));
    missile->x=x;
    missile->y=y;
    missile->type=type;
    missile->explosion=0;
    missile->vivant=1;

    switch (type)
    {
        case 0:
            missile->tailleX=34;
            missile->tailleY=17;
            missile->pasX=0.9;
            missile->pasY=0;
            missile->missile=load_bitmap("missile.cache.bmp",NULL);
            break;

        case 1:
            missile->tailleX=34;
            missile->tailleY=18;
            missile->pasX=0.9;
            missile->pasY=0;
            missile->missile=load_bitmap("missile1.cache.bmp",NULL);
            break;

        case 2:
            missile->tailleX=60;
            missile->tailleY=57;
            missile->pasX=-0.5;
            missile->pasY=0;
            missile->pdv=21;
            missile->missile=load_bitmap("vol.cache.bmp",NULL);
    }
    return missile;
}
