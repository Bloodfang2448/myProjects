#include "header.h"

void recup_images_anime(t_sprite*helico ,char*fname,int nb_col)
{
BITMAP*tmp=NULL;
int x,y,i;

   tmp=load_bitmap(fname,NULL);
   if (!tmp)
   {
      allegro_message("probleme recup animation");
   }

   for (i=0;i<helico->nb_image;i++)
    {
      x= (i%nb_col) * helico->tailleX;
      y= (i/nb_col) * helico->tailleY;
      blit(tmp,helico->anim[i],x,y,0,0,helico->tailleX,helico->tailleY);
    }
   destroy_bitmap(tmp);
}
