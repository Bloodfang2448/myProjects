#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

#include <allegro.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct sprite
{
    float x;
    float y;
    float pasX;
    float pasY;
    int tailleX,tailleY;
    int retardX,retardY;
    int imagecourante;
    int nb_image;
    int maxtemps;
    int temps;
    int sens;
    BITMAP**anim;
    int vivant;
    int type;
    float pdv;
    int max_missile;
    int n;
    struct sprite** miss;
    BITMAP* missile;
    int temp;
    int temp1;
    int temp2;
    int temp3;
}t_sprite;




enum{helico,boss,NB_SPRITE};
void construct_sprites(t_sprite*tab[]);
void init_position(t_sprite*helico,float posx,float posy,int tailleX, int tailleY,float pasX, float pasY,int retardX, int retardY);
void init_image(t_sprite*helico,int nbimage, int maxtemps,int sens,char*name, int nb_col);
void recup_images_anime(t_sprite*helico,char*fname,int nb_col);
t_sprite* creer_missile(int x,int y,int type);
void actualiser_missile(t_sprite* missile);
void dessiner_missile(BITMAP *bmp,t_sprite* missile);
t_sprite* liste_creer_missile(int missile);
t_sprite* ajouter_missile(t_sprite *la,int x,int y,int type);
void enlever_missile(t_sprite *la,int i);
void liste_actualiser_missile(t_sprite *la);
void liste_dessiner_missile(BITMAP *bmp,t_sprite *la);
void avance_missile(BITMAP*dest, t_sprite *helico, t_sprite *missile);
t_sprite* creer_missile2(int x,int y,int type);
t_sprite* ajouter_missile2(t_sprite *la,int x,int y,int type);
int avance_sprite(BITMAP*dest, t_sprite *helico, t_sprite *missile, int compteur3, int apparition);
int avance_sprite_2(BITMAP*dest, t_sprite *helico, t_sprite *missile, int compteur3, int apparition);
int avance_sprite_3(BITMAP*dest, t_sprite *helico, t_sprite *missile, int compteur3, int apparition,int compteur);
int avance_sprite_boss(BITMAP*dest, t_sprite *helico, int x, int y, int cpt2);


void collision(t_sprite *helico,t_sprite *missile);
void collision_liste_acteurs(t_sprite *helico,t_sprite *la);
void construct_sprites_boss(t_sprite*tab[]);
void collision_boss(t_sprite *helico,t_sprite *missile);
void collision_liste_boss(t_sprite *helico,t_sprite *la);
int collision_ennemi(t_sprite *missile,t_sprite *ennemis, int score);
int liste_collision_ennemi(t_sprite *missile, int score);

#endif // HEADER_H_INCLUDED
