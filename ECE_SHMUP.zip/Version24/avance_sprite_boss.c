#include "header.h"

int avance_sprite_boss(BITMAP*dest, t_sprite *helico, int x, int y, int cpt2)
{
        if (key[KEY_ESC])
        {
            helico->pdv=80;
            helico->vivant=1;
        }

    if(helico->vivant==1)
    {
       if ( ++helico->temps > helico->maxtemps)
    {
      helico->imagecourante= ((helico->imagecourante+helico->sens)+helico->nb_image)%helico->nb_image;
      helico->temps=0;
    }

     circlefill(dest,x,y,cpt2,makecol(255,0,0));

    rectfill(dest,helico->x+60,helico->y+164,helico->x+helico->pdv+60,helico->y+167,makecol(255,0,0));
    rect(dest,helico->x+60,helico->y+164,helico->x+140,helico->y+168,makecol(0,0,0));
    rect(dest,helico->x+60,helico->y+164,helico->x+130,helico->y+168,makecol(0,0,0));
    rect(dest,helico->x+60,helico->y+164,helico->x+120,helico->y+168,makecol(0,0,0));
    rect(dest,helico->x+60,helico->y+164,helico->x+110,helico->y+168,makecol(0,0,0));
    rect(dest,helico->x+60,helico->y+164,helico->x+100,helico->y+168,makecol(0,0,0));
    rect(dest,helico->x+60,helico->y+164,helico->x+90,helico->y+168,makecol(0,0,0));
    rect(dest,helico->x+60,helico->y+164,helico->x+80,helico->y+168,makecol(0,0,0));
    rect(dest,helico->x+60,helico->y+164,helico->x+70,helico->y+168,makecol(0,0,0));

    draw_sprite(dest,helico->anim[helico->imagecourante],helico->x,helico->y);
    }
    return helico->vivant;
}

