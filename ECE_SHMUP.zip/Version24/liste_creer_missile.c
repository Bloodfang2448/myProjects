#include "header.h"

t_sprite* liste_creer_missile(int missile)
{
    t_sprite *nouv;
    int i;
    nouv=(t_sprite *)malloc(sizeof(t_sprite));
    nouv->max_missile=missile;
    nouv->n=0;
    nouv->miss=(t_sprite**)malloc(missile*sizeof(t_sprite*));
    nouv->temp=0;
    nouv->temp1=0;
    nouv->temp2=0;
    nouv->temp3=0;

    for (i=0;i<missile;i++)
    {
        nouv->miss[i]=NULL;
    }
    return nouv;
}
