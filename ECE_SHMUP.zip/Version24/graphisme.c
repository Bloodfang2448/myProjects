#include "header.h"

void graphisme(t_sprite* helico)
{
    circlefill(helico->missile,10,10,10,makecol(255,0,0));
}
