#include "header.h"

void liste_dessiner_missile(BITMAP *bmp,t_sprite *la)
{
    int i;
    for (i=0;i<la->max_missile;i++)
    {
        if (la->miss[i]!=NULL)
        {
            dessiner_missile(bmp,la->miss[i]);
        }
    }
}
