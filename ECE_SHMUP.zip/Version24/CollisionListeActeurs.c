#include "header.h"

void collisionListeActeurs(t_sprite *helico,t_sprite *la){

    int i;

    for (i=0;i<la->n;i++)
    {
        if (la->miss[i]!=NULL)
        {
            collision(helico,la->miss[i]);
        }
    }

}
