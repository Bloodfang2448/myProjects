#include "header.h"

void dessiner_missile(BITMAP *bmp,t_sprite* missile)
{

        switch(missile->type)
        {
        case 0:
            draw_sprite(bmp,missile->missile,missile->x,missile->y);
            break;
        case 1:
            draw_sprite(bmp,missile->missile,missile->x,missile->y);
            break;
        case 2:
            draw_sprite(bmp,missile->missile,missile->x,missile->y);
            break;
        case 3:
            draw_sprite(bmp,missile->missile,missile->x,missile->y);
            break;

    }
}
