#include "header.h"

void construct_sprites(t_sprite*tab[])
{
int i;
    for (i=0; i<NB_SPRITE; i++)
    {
       tab[i]=(t_sprite*)malloc(sizeof(t_sprite));
    }
    init_position(tab[helico],200,300,104,38,0.8,0.8,1,1);
    init_image(tab[helico],4,15,1,"helico.bmp",1);

    init_position(tab[boss],550,339,206,163,0,0,0,0);
    init_image(tab[boss],3,333,1,"boss.bmp",3);
}

