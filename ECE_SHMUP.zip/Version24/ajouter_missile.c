#include "header.h"

t_sprite* ajouter_missile(t_sprite *la,int x,int y,int type)
{
    int i=0;
    t_sprite *missile;
    if (la->n >= la->max_missile)
    {
        return NULL;
    }
    missile=creer_missile(x,y,type);

    while (la->miss[i]!=NULL && i<la->max_missile)
    {
        i++;
    }

    if (i<la->max_missile)
    {
        la->miss[i]=missile;
        la->n++;
    }

    else
        allegro_message("Anomalie gestion ajouterActeur : liste corrompue");

    return missile;
}
