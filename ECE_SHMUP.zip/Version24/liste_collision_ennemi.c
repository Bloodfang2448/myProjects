#include "header.h"

int liste_collision_ennemi(t_sprite *missile, int score)
{
    int i,j;

    for (i=0;i<missile->n;i++)
    {
        for(j=0;j<missile->n;j++)
        {
            if (missile->miss[j]!=NULL&&missile->miss[i]!=NULL)
            {
                score=collision_ennemi(missile->miss[i],missile->miss[j],score);
            }
        }
    }
    return score;

}
