#include "header.h"

void collision_liste_boss(t_sprite *helico,t_sprite *la)
{
    int i;
    for (i=0;i<la->n;i++)
        if (la->miss[i]!=NULL)
        {
            collision_boss(helico,la->miss[i]);
        }
}
