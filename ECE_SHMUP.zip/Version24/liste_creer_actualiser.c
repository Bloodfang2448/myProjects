#include "header.h"

void liste_actualiser_missile(t_sprite *la)
{
    int i;
    for (i=0;i<la->max_missile;i++)
    {
        if (la->miss[i]!=NULL)
        {
            actualiserActeur(la->miss[i]);
            if (!la->miss[i]->vivant)
            {
                enlever_missile(la,i);
            }
        }
    }
}

