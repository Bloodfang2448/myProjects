#include "header.h"

void actualiser_missile(t_sprite* missile)
{
    missile->x=missile->x+missile->pasX;
    missile->y=missile->y+missile->pasY;

    if (missile->x+missile->tailleX<0 || missile->x>SCREEN_W || missile->y+missile->tailleY<0 || missile->y>SCREEN_H )
    {
        missile->vivant=0;
    }

}
