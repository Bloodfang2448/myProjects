//#include "header.h"
//
//void liste_collision_missile(t_sprite *missile,t_sprite *la)
//{
//
//    int i;
//
//    for (i=0;i<la->max_missile;i++)
//    {
//        if (la->miss[i]!=NULL)
//        {
//            collision_missile(missile,la->miss[i]);
//        }
//    }
//
//}
