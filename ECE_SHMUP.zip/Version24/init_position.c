#include "header.h"

void init_position(t_sprite*helico,float posx,float posy,int tailleX, int tailleY,float pasX, float pasY,int retardX, int retardY)
{
   helico->x=posx;
   helico->y=posy;
   helico->tailleX=tailleX;
   helico->tailleY=tailleY;
   helico->pasX=pasX;
   helico->pasY=pasY;
   helico->retardX=retardX;
   helico->retardY=retardY;
   helico->pdv=80;
   helico->vivant=1;
}
