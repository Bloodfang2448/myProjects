//#include "header.h"
//
//void avance_missile(BITMAP*dest, t_sprite *helico, t_sprite *missile)
//{
//
//    int alea;
//    alea=rand()%(440-0+1)+0;
//
//    if(helico->vivant==1)
//    {
////    missile->temp++;
////    missile->temp1++;
////    missile->temp2++;
////
////    if (key[KEY_SPACE] && missile->temp>=150)
////    {
////        ajouter_missile(missile,helico->x+missile->tailleX+100,helico->y+missile->tailleY+42,0);
////        missile->temp=0;
////    }
////
////    if (key[KEY_D] && missile->temp1>=150)
////    {
////        ajouter_missile(missile,helico->x+missile->tailleX+100,helico->y+missile->tailleY+42,1);
////        missile->temp1=0;
////    }
////
////    if(missile->temp2>=300)
////    {
////        ajouter_missile(missile,SCREEN_W,alea,2);
////        missile->temp2=0;
////        missile->pdv=0;
////    }
//
//
//
//   draw_sprite(dest,helico->anim[helico->imagecourante],helico->x,helico->y);
//
//    }
//}
