#include "header.h"

void collision_boss(t_sprite *helico,t_sprite *missile)
{

if(missile->type==0)
{
    if ((helico->x > missile->x + missile->tailleX -50) ||
        (helico->y > missile->y + missile->tailleY -5) ||
        (missile->x > helico->x + helico->tailleX -25) ||
        (missile->y > helico->y + helico->tailleY -5))
        {

        }
        else
           {
               missile->vivant=0;
               helico->pdv=helico->pdv-1;
               if(helico->pdv<0)
               {
                   helico->pdv=0;
                   helico->vivant=0;
               }

               helico->y=rand()%(300-0+1)+0;
           }
}





           if(missile->type==1)
           {
    if ((helico->x > missile->x + missile->tailleX -50) ||
        (helico->y > missile->y + missile->tailleY -5) ||
        (missile->x > helico->x + helico->tailleX -25) ||
        (missile->y > helico->y + helico->tailleY -5))
        {

        }
        else
           {
               missile->vivant=0;
               helico->pdv=helico->pdv-2;
               if(helico->pdv<0)
               {
                   helico->pdv=0;
                   helico->vivant=0;
               }

               helico->y=rand()%(300-0+1)+0;
           }

           }


}
