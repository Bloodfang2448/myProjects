#include "header.h"

void avance_sprite2(BITMAP*dest, t_sprite *helico, t_sprite *missile)
{
    int alea;
    alea=rand()%(440-0+1)+0;

    if(helico->vivant==1)
    {

        if (key[KEY_LEFT])
    {
        helico->x = helico->x-helico->pasX;
        if (helico->x<0)
        {
            helico->x=0;
        }
    }

    if (key[KEY_RIGHT])
    {
        helico->x = helico->x+helico->pasX;
        if (helico->x+helico->tailleX > SCREEN_W)
        {
            helico->x=SCREEN_W-helico->tailleX;
        }
    }

    if (key[KEY_UP])
    {
        helico->y = helico->y-helico->pasY;
        if (helico->y<0)
        {
            helico->y=0;
        }
    }

    if (key[KEY_DOWN])
    {
        helico->y = helico->y+helico->pasY;
        if (helico->y+helico->tailleY > SCREEN_H)
        {
            helico->y=SCREEN_H-helico->tailleY;
        }
    }


   if ( ++helico->temps > helico->maxtemps)
    {
      helico->imagecourante= ((helico->imagecourante+helico->sens)+helico->nb_image)%helico->nb_image;
      helico->temps=0;
    }

    if(helico->y>SCREEN_H-140)
        {
        helico->pasY=0.1;
        helico->pasX=0.1;
        helico->pdv=helico->pdv-0.02;
        }

    if(helico->pdv<50)
        {
        helico->vivant=0;
        }

    if(helico->y<SCREEN_H-140)
        {
        helico->pasY=0.7;
        helico->pasX=0.7;
        }



    rectfill(dest,helico->x+50,helico->y+35,helico->x+helico->pdv,helico->y+39,makecol(255,0,0));
    rect(dest,helico->x+50,helico->y+35,helico->x+80,helico->y+39,makecol(0,0,0));
    rect(dest,helico->x+50,helico->y+35,helico->x+60,helico->y+39,makecol(0,0,0));
    rect(dest,helico->x+60,helico->y+35,helico->x+70,helico->y+39,makecol(0,0,0));


    missile->temp++;
    missile->temp1++;
    missile->temp2++;

    if (key[KEY_SPACE] && missile->temp>=150)
    {
        ajouter_missile2(missile,helico->x+missile->tailleX+80,helico->y+missile->tailleY+22,0);
        missile->temp=0;
    }

    if (key[KEY_D] && missile->temp1>=150)
    {
        ajouter_missile2(missile,helico->x+missile->tailleX+80,helico->y+missile->tailleY+22,1);
        missile->temp1=0;
    }

    if(missile->temp2>=300)
    {
        ajouter_missile2(missile,SCREEN_W,alea,2);
        missile->temp2=0;
        missile->pdv=0;
    }

    draw_sprite(dest,helico->anim[helico->imagecourante],helico->x,helico->y);
    }
}
