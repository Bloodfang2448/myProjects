#include "header.h"

void collision(t_sprite *helico,t_sprite *missile)
{
if(missile->type==2)
{
    if ((helico->x > missile->x + missile->tailleX -10) ||
        (helico->y > missile->y + missile->tailleY -5) ||
        (missile->x > helico->x + helico->tailleX -25) ||
        (missile->y > helico->y + helico->tailleY -10))
        {

        }
        else
           {
               helico->pdv=helico->pdv-0.147*helico->pdv;
               helico->x=10;
               helico->y=rand()%400;
           }
    }

    if(missile->type==3)
{
    if ((helico->x > missile->x + missile->tailleX -10) ||
        (helico->y > missile->y + missile->tailleY -5) ||
        (missile->x > helico->x + helico->tailleX -25) ||
        (missile->y > helico->y + helico->tailleY -10))
        {

        }
        else
           {
               helico->pdv=80;
               missile->vivant=0;
                SAMPLE *soin = load_sample("soin.wav");
                play_sample(soin, 400, 128, 1000, 0);
           }
    }
}


