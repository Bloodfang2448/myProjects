#include "header.h"

void init_image( t_sprite*helico,int nbimage, int maxtemps,int sens,char*name, int nb_col)
{
int i;
   helico->maxtemps=maxtemps;
   helico->sens=sens;
   helico->nb_image=nbimage;
   helico->anim=(BITMAP**)malloc(sizeof(BITMAP*)*nbimage);
   for (i=0;i<nbimage;i++)
    {
      helico->anim[i]=create_bitmap(helico->tailleX,helico->tailleY);
      if(!helico->anim[i])
      {
         allegro_message("probleme creation sprite");
      }
   }
   recup_images_anime(helico,name,nb_col);
}
