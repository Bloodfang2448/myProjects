#include "header.h"

void collision_missile(t_sprite* missile,t_sprite* la)
{
    if ( missile->explosion==0 )
    {
//
//        vx = acteur->x+acteur->tx/2 - (ennemi->x+ennemi->tx/2);
//        vy = acteur->y+acteur->ty/2 - (ennemi->y+ennemi->ty/2);
//
//        // calcul distance au carr� au centre de la cible (Pythagore)
//        // (on reste sur le carr� pour �viter de calculer la racine)
//        d2 = vx*vx + vy*vy;
//
//        // si dans le disque alors destin...
        if ((missile->x&&missile->type==2)==(missile->x&&missile->type==1))
        {
            explosion_missile(missile);
        }

        if((missile->x&&missile->type==2)==(missile->x&&missile->type==0))
        {
            explosion_missile(missile);
        }
    }
}
