#include "header.h"

void explosion_missile(t_sprite* missile)
{
    missile->explosion=1;
    missile->exp_graph=0;
}
