#include "header.h"

int collision_ennemi(t_sprite *missile,t_sprite *ennemis, int score)
{
    if((missile->type==0||missile->type==1)&&(ennemis->type==2))
    {
        if ((missile->x > ennemis->x + ennemis->tailleX -10) ||
            (missile->y > ennemis->y + ennemis->tailleY -10) ||
            (ennemis->x > missile->x + missile->tailleX -10) ||
            (ennemis->y > missile->y + missile->tailleY -10))
            {

            }
            else
            {
                if(missile->type==0)
                {
                    missile->vivant=0;
                    ennemis->pdv=ennemis->pdv-5;
                    score=score+50;

                    if(ennemis->pdv==0)
                    {
                        ennemis->vivant=0;
                    }

                }
                else if(missile->type==1)
                {
                    missile->vivant=0;
                    ennemis->vivant=0;
                    score=score+100;
                }
            }
    }
    return score;
}

