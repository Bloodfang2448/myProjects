#include "header.h"

int main()
{

    int j=0;
    int compteur=0;
    float w=0;
    int pause=0;
    int comp=0,comp1=0,comp2=0,comp3=0;
    int win;
    float boss1=100,boss2=50,boss3=100;
    int score=0;
    int cond=1;
    int men=1;



    int apparition;
    allegro_init();
    install_keyboard();
    install_mouse();
    srand(time(NULL));
    install_sound(DIGI_AUTODETECT, MIDI_AUTODETECT, NULL);
    set_color_depth(desktop_color_depth());
    if (set_gfx_mode(GFX_AUTODETECT_WINDOWED, 800, 600, 0, 0) != 0)
    {
        allegro_message("probleme GFX mode");
        allegro_exit();
        exit(EXIT_FAILURE);
    }
    t_sprite* helico[NB_SPRITE];
    t_sprite* missile;

    missile=liste_creer_missile(500);
    BITMAP *page;
    BITMAP *decor;
    BITMAP *decor2;
    BITMAP *decor3;
    BITMAP *premenu;
    BITMAP *menu;
    BITMAP *menu2;
    BITMAP *menu3;
    BITMAP *griffe;
    BITMAP *defaite;
    BITMAP *victoire;



    show_mouse(screen);
    page=create_bitmap(SCREEN_W,SCREEN_H);



    decor=load_bitmap("jungle.bmp",NULL);
    if (!decor)
    {
        allegro_message("probleme decor");
    }

        defaite=load_bitmap("defaite.bmp",NULL);
            if (!defaite)
    {
        allegro_message("probleme defaite");
    }

    decor2=load_bitmap("jungle2.bmp",NULL);
    if (!decor2)
    {
        allegro_message("probleme decor2");
    }

    decor3=load_bitmap("jungle3.bmp",NULL);
    if (!decor3)
    {
        allegro_message("probleme decor3");
    }

    menu=load_bitmap("menu.bmp",NULL);
    if(!menu)
    {
        allegro_message("probleme menu");
    }

    menu2=load_bitmap("menu1.bmp",NULL);
    if(!menu2)
    {
        allegro_message("probleme menu2");
    }

    menu3=load_bitmap("menu2.bmp",NULL);
    if(!menu3)
    {
        allegro_message("probleme menu3");
    }

    griffe=load_bitmap("griffe.bmp",NULL);
    if(!griffe)
    {
        allegro_message("probleme griffe");
    }

     victoire=load_bitmap("victoire.bmp",NULL);
        if (!victoire)
    {
        allegro_message("probleme victoire");
    }

    construct_sprites(helico);
    premenu=load_bitmap("premenu.bmp",NULL);

    blit(premenu,screen,0,0,0,0,SCREEN_W,SCREEN_H);
    rest(5000);
    destroy_bitmap(premenu);

    while (0<1)
    {

    boss1=boss1+0.4;
    if(boss1>600)
    {
        boss1=100;
    }

    boss2=boss2+0.4;
    if(boss2>450)
    {
        boss2=50;
    }


    boss3++;
    if(boss3>150)
    {
        boss3=100;
    }


    if(key[KEY_ESC])
    {
        men++;
        rest(150);
        compteur=0;
        score=0;
        comp3=0;
    }

        if(key[KEY_P])
        {
            pause++;
            rest(150);
        }




        if(pause%2==0)
        {


            if(key[KEY_F3])
            {
                draw_sprite(menu,griffe,0,0);
                if(comp3%2==0)
                {
                    SAMPLE *claw = load_sample("raptor.wav");
                    play_sample(claw, 125, 128, 1000, 0);
                }
            }

                    if(men%2==0)
        {
            clear(menu);
            clear(page);
            blit(menu2,menu,0,0,0,0,SCREEN_W,SCREEN_H);
        }

            blit(menu,screen,0,0,0,0,SCREEN_W,SCREEN_H);

            if(key[KEY_ENTER])
            {
                j++;
            }


/////////////// *************** NIVEAU1 *************** ///////////////

            if(j!=0)
            {
                if(mouse_x>310&&mouse_x<485&&mouse_y>260&&mouse_y<330&&mouse_b&1)
                {
                    clear(menu);
                    clear(page);
                    comp++;
                    compteur=0;
                    comp1=0;
                    comp2=0;
                    if(comp3%2==0)
                    {
                        MIDI *lvl1 = load_midi("Airwolf.mid");
                        play_midi(lvl1, 1);
                    }
                }

                if(comp!=0&&men%2==1&&comp1==0&&comp2==0)
                {

                    blit(decor,page,0,0,w-decor->w,0,decor->w,decor->h);
                    w=w-0.25;
                    compteur++;
                    if(w<0)
                    {
                        w=decor->w;
                    }
                    if(compteur>30000)
                    {
                        w=w+0.25;
                    }

                    apparition=300;
                    if(compteur>0&&compteur<30000)
                    {

                        win=avance_sprite(page,helico[0],missile,comp3,apparition);

                        collision_liste_acteurs(helico[0],missile);
                        score=liste_collision_ennemi(missile,score);
                        liste_actualiser_missile(missile);
                        liste_dessiner_missile(page,missile);
                        textprintf_ex(page, font, 10, 10, makecol(255, 0, 0),-1, "Score: %d", score);
                    }

                     if(win==1&&compteur>30000)
                    {

                       blit(victoire,page,0,0,0,0,SCREEN_W,SCREEN_H);
                       textprintf_ex(page, font, 10, 10, makecol(255, 100, 200),-1, "Score: %d", score);
                    }


                    if(win==0&&compteur<30000)
                    {
                        blit(defaite,page,0,0,0,0,SCREEN_W,SCREEN_H);
                        textprintf_ex(page, font, 10, 10, makecol(255, 0, 0),-1, "Score: %d", score);
                    }

                    blit(page,menu,0,0,0,0,SCREEN_W,SCREEN_H);
                    blit(decor,page,0,0,w,0,decor->w,decor->h);
                    rest(0.9999999999999999999);
                }


/////////////// *************** NIVEAU2 *************** ///////////////

            if(mouse_x>310&&mouse_x<485&&mouse_y>360&&mouse_y<430&&mouse_b&1)
                {
                     clear(menu);
                    clear(page);
                    comp1++;
                    comp=0;
                    comp2=0;
                    compteur=0;
                    if(comp3%2==0)
                    {
                        MIDI *lvl2 = load_midi("Sabaton.mid");
                        play_midi(lvl2, 1);
                    }
                }

                if(comp1!=0&&men%2==1&&comp==0&&comp2==0)
                {

                    blit(decor2,page,0,0,w-decor2->w,0,decor2->w,decor2->h);
                    w=w-0.25;
                    compteur++;
                    if(w<0)
                    {
                        w=decor2->w;
                    }
                    if(compteur>30000)
                    {
                        w=w+0.25;
                    }

                    apparition=150;

                    if(compteur>0&&compteur<30000)
                    {
                        win=avance_sprite_2(page,helico[0],missile,comp3,apparition);
                        liste_actualiser_missile(missile);
                        collision_liste_acteurs(helico[0],missile);
                        score=liste_collision_ennemi(missile,score);
                        liste_dessiner_missile(page,missile);
                        textprintf_ex(page, font, 10, 10, makecol(255, 0, 0),-1, "Score: %d", score);
                    }

                     if(win==1&&compteur>30000)
                    {
                       blit(victoire,page,0,0,0,0,SCREEN_W,SCREEN_H);
                       MIDI *victoire= load_midi("victoire.mid");
                        play_midi(victoire,0);
                       textprintf_ex(page, font, 10, 10, makecol(255, 100, 200),-1, "Score: %d", score);
                    }


                    if(win==0&&compteur<30000)
                    {
                       blit(defaite,page,0,0,0,0,SCREEN_W,SCREEN_H);
                       textprintf_ex(page, font, 10, 10, makecol(255, 0, 0),-1, "Score: %d", score);
                    }

                    blit(page,menu,0,0,0,0,SCREEN_W,SCREEN_H);
                    blit(decor2,page,0,0,w,0,decor2->w,decor2->h);
                }


/////////////// *************** NIVEAU3 *************** ///////////////


                       if(mouse_x>310&&mouse_x<485&&mouse_y>460&&mouse_y<530&&mouse_b&1)
                {
                    clear(menu);
                    clear(page);
                    comp2++;
                    compteur=0;
                    comp=0;
                    comp1=0;
                    if(comp3%2==0)
                    {
                        MIDI *lvl3 = load_midi("lvl3.mid");
                        play_midi(lvl3, 1);
                    }
                }

                if(comp2!=0&&men%2==1&&comp==0&&comp1==0)
                {

                    blit(decor3,page,0,0,w-decor3->w,0,decor3->w,decor3->h);
                    w=w-0.25;
                    compteur++;
                    if(w<0)
                    {
                        w=decor3->w;
                    }
                    if(compteur>30000)
                    {
                        w=w+0.25;
                    }




                    if(compteur>0&&compteur<30000)
                    {
                        apparition=100;
                    }

                    if(compteur>30000)
                    {
                        apparition=999999;
                        cond=avance_sprite_boss(page,helico[1],boss1,boss2,boss3);
                        collision_liste_boss(helico[1],missile);
                    }

                        win=avance_sprite_3(page,helico[0],missile,comp3,apparition,compteur);
                        collision_liste_acteurs(helico[0],missile);
                        score=liste_collision_ennemi(missile,score);
                        liste_actualiser_missile(missile);
                        liste_dessiner_missile(page,missile);
                        textprintf_ex(page, font, 10, 10, makecol(255, 0, 0),-1, "Score: %d", score);



                    if(win==1&&compteur>30000&&cond==0)
                    {
                       blit(victoire,page,0,0,0,0,SCREEN_W,SCREEN_H);
                       MIDI *victoire= load_midi("victoire.mid");
                        play_midi(victoire,0);
                       textprintf_ex(page, font, 10, 10, makecol(255, 100, 200),-1, "Score: %d", score);
                    }

                    if(win==0)
                    {
                        blit(defaite,page,0,0,0,0,SCREEN_W,SCREEN_H);
                        textprintf_ex(page, font, 10, 10, makecol(255, 0, 0),-1, "Score: %d", score);
                    }

                    blit(page,menu,0,0,0,0,SCREEN_W,SCREEN_H);
                    blit(decor3,page,0,0,w,0,decor3->w,decor3->h);
                }


            }




/////////////// *************** SON *************** ///////////////

            if(mouse_x>0&&mouse_x<100&&mouse_y>500&&mouse_y<600&&j!=0&&mouse_b&1)
            {
                comp1=0;
                comp2=0;
                comp=0;
                comp3++;
                if(comp3>1)
                {
                    comp3=0;
                }
                rest(150);
            }



/////////////// *************** MENU *************** ///////////////


            if(comp3==1&&j!=0&&comp==0&&comp1==0&&comp2==0&&men%2==1)
            {
                blit(menu3,menu,0,0,0,0,SCREEN_W,SCREEN_H);
            }

            if(comp3==0&&j!=0&&comp==0&&comp1==0&&comp2==0)
            {
                blit(menu2,menu,0,0,0,0,SCREEN_W,SCREEN_H);
            }


        if(mouse_x>710&&mouse_x<800&&mouse_y>510&&mouse_y<600&&j!=0&&mouse_b&1)
        {
            exit(1);
        }


        }
    }

    return 0;
}
END_OF_MAIN();
