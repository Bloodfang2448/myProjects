#include "header.h"

void enlever_missile(t_sprite *la,int i)
{
    if (la->miss[i]!=NULL)
    {
        free(la->miss[i]);
        la->miss[i]=NULL;
        la->n--;
    }
}
