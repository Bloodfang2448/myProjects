#include "gestion_fournisseurs.h"


void saisie_liste_fournisseur(int nb, Fourni TABFOURNISSEUR[]){

}
void affiche_liste_fournisseur(int nb, Fourni TABFOURNISSEUR[]){

}
void tri_liste_code_fournisseur(int nb, Fourni TABFOURNISSEUR[]){

}
void tri_liste_adr_fournisseur(int nb, Fourni TABFOURNISSEUR[]){

}
int rechercher_fournisseur_in_tab(int nb, Fourni TABFOURNISSEUR[], Fourni fourniToFind){

}
int insert_nouveau_fournisseur(int nb, Fourni TABFOURNISSEUR[], Fourni fourniToFind){

}
void load_liste_fournisseurs_from_file(int* nb, Fourni TABFOURNISSEUR[], char* file_path){

}
void save_liste_fournisseurs_into_file(int nb, Fourni TABFOURNISSEUR[], char* file_path){

}

void affiche_listefournisseurs_into_file(Fourni TABFOURNISSEUR[], char* file_path){

}
void save_liste_fournisseurs_into_bdd(int* nb, Fourni TABFOURNISSEUR[], char* file_path){

}
void affiche_liste_fournisseurs_into_bdd(Fourni TABFOURNISSEUR[], char* file_path){

}


void saisie_date(date * d_to_insert)
{
     //Saisie de la date
    printf("Jour : ");
    scanf("%d", d_to_insert->jour);

    printf("Mois : ");
    scanf("%d", d_to_insert->mois);

    printf("Annee : ");
    scanf("%d", d_to_insert->annee);
}

void affiche_date(date d)
{
    printf("%d/%d/%d",d.jour,d.mois,d.annee);
}

