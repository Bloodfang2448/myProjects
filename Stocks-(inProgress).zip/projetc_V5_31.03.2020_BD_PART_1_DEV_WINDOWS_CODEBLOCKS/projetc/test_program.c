
#include"gestion_produits.h"

void main()
{
    /*D�clartion des variable**/
    int N;
    int CHOIX ;
    Prod tabProd[MAX_SIZE_TAB];
    char nom_file_to_load[100];
    char nom_file_to_save[100];
    char nom_bd_to_load[1000];
    char nom_bd_to_save[1000];
    char chaineInput[1000]; //pour �criture de chaine sous allegro
    Prod p;
//    MYSQL mysql;
    int DBOPEN = 0;
    int nbMenu=0, quitting=0;

        allegro_init();
        install_keyboard();
        install_mouse();
        show_mouse(screen);
        srand(time(NULL));
        install_sound(DIGI_AUTODETECT, MIDI_AUTODETECT, NULL);
        set_color_depth(desktop_color_depth());
        if (set_gfx_mode(GFX_AUTODETECT_WINDOWED, 1280, 720, 0, 0) != 0)
        {
            allegro_message("probleme GFX mode");
            allegro_exit();
            exit(EXIT_FAILURE);
        }

        //MENUS
        //ACCUEIL
        BITMAP* menu0 = load_bitmap("imgs/Diapositive1.bmp", NULL);
        //SECTION PRODUIT
        BITMAP* menu10 = load_bitmap("imgs/Diapositive2.bmp", NULL);
        BITMAP* menu11 = load_bitmap("imgs/Diapositive3.bmp", NULL);
        BITMAP* menu12 = load_bitmap("imgs/Diapositive4.bmp", NULL);
        BITMAP* menu13 = load_bitmap("imgs/Diapositive5.bmp", NULL);
        BITMAP* menu14 = load_bitmap("imgs/Diapositive6.bmp", NULL);
        BITMAP* menu15 = load_bitmap("imgs/Diapositive7.bmp", NULL);
        //SECTION FOURNISSEUR
        BITMAP* menu20 = load_bitmap("imgs/Diapositive8.bmp", NULL);
        BITMAP* menu21 = load_bitmap("imgs/Diapositive9.bmp", NULL);
        BITMAP* menu22 = load_bitmap("imgs/Diapositive10.bmp", NULL);
        BITMAP* menu23 = load_bitmap("imgs/Diapositive11.bmp", NULL);
        BITMAP* menu24 = load_bitmap("imgs/Diapositive12.bmp", NULL);
        BITMAP* menu25 = load_bitmap("imgs/Diapositive13.bmp", NULL);
        //SECTION FICHIER
        BITMAP* menu30 = load_bitmap("imgs/Diapositive16.bmp", NULL);
        BITMAP* menu31 = load_bitmap("imgs/Diapositive14.bmp", NULL);
        BITMAP* menu32 = load_bitmap("imgs/Diapositive15.bmp", NULL);
        BITMAP* buffer = create_bitmap(1280,720);
        BITMAP* buffer2= create_bitmap(1280,720);

        while (nbMenu != -1){

            switch(nbMenu){ //blits et clics situationnels de lancement de fonctions de rang 3

            case 0 : blit(menu0,buffer,0,0,0,0,1280,720);
                     break;

            case 10 : blit(menu10,buffer,0,0,0,0,1280,720);
                     break;

            case 11 : blit(menu11,buffer,0,0,0,0,1280,720);
                     break;

            case 12 : blit(menu12,buffer,0,0,0,0,1280,720);
                     break;

            case 13 : blit(menu13,buffer,0,0,0,0,1280,720);
                     break;

            case 14 : blit(menu14,buffer,0,0,0,0,1280,720);
                     break;

            case 15 : blit(menu15,buffer,0,0,0,0,1280,720);
                     break;

            case 20 : blit(menu20,buffer,0,0,0,0,1280,720);
                     break;

            case 21 : blit(menu21,buffer,0,0,0,0,1280,720);
                     break;

            case 22 : blit(menu22,buffer,0,0,0,0,1280,720);
                     break;

            case 23 : blit(menu23,buffer,0,0,0,0,1280,720);
                     break;

            case 24 : blit(menu24,buffer,0,0,0,0,1280,720);
                     break;

            case 25 : blit(menu25,buffer,0,0,0,0,1280,720);
                     break;

            case 30 : blit(menu30,buffer,0,0,0,0,1280,720);
                     break;

            case 31 : blit(menu31,buffer,0,0,0,0,1280,720);
                     break;

            case 32 : blit(menu32,buffer,0,0,0,0,1280,720);
                     break;


            }

        if ((mouse_x>50)&&(mouse_x<285)) //MENUS DE GAUCHE
        {
            if ((mouse_y>45)&&(mouse_y<180) && (mouse_b&1))
            {
                nbMenu = 10;
            }

            else if ((mouse_y>230)&&(mouse_y<365) && (mouse_b&1))
            {
                nbMenu = 20;
            }

            else if ((mouse_y>415)&&(mouse_y<550) && (mouse_b&1))
            {
                nbMenu = 30;
            }
        }

        if ((mouse_y>580)&&(mouse_y<710)) //QUITTER
        {
            if ((mouse_x>1005)&&(mouse_x<1240) && (mouse_b&1))
            {
                nbMenu = -1;
            }
        }

        if ((nbMenu>=10)&&(nbMenu<=15)&& (mouse_x>370)&&(mouse_x<600)){ //MENUS SECONDAIRES SECTION PRODUIT
            if ((mouse_y>67)&&(mouse_y<127)&&(mouse_b&1)) {nbMenu = 11;}
            if ((mouse_y>157)&&(mouse_y<217)&&(mouse_b&1)) {nbMenu = 12;}
            if ((mouse_y>247)&&(mouse_y<307)&&(mouse_b&1)) {nbMenu = 13;}
            if ((mouse_y>337)&&(mouse_y<397)&&(mouse_b&1)) {nbMenu = 14;}
            if ((mouse_y>427)&&(mouse_y<487)&&(mouse_b&1)) {nbMenu = 15;}

        }

        if ((nbMenu>=20)&&(nbMenu<=25)&& (mouse_x>370)&&(mouse_x<600)){ //MENUS SECONDAIRES SECTION FOURNISSEUR
            if ((mouse_y>67)&&(mouse_y<127)&&(mouse_b&1)) {nbMenu = 21;}
            if ((mouse_y>157)&&(mouse_y<217)&&(mouse_b&1)) {nbMenu = 22;}
            if ((mouse_y>247)&&(mouse_y<307)&&(mouse_b&1)) {nbMenu = 23;}
            if ((mouse_y>337)&&(mouse_y<397)&&(mouse_b&1)) {nbMenu = 24;}
            if ((mouse_y>427)&&(mouse_y<487)&&(mouse_b&1)) {nbMenu = 25;}

        }

        if ((nbMenu>=30)&&(nbMenu<=32)&& (mouse_x>430)&&(mouse_x<690)){ //MENUS SECONDAIRES SECTION FOURNISSEUR
            if ((mouse_y>70)&&(mouse_y<152)&&(mouse_b&1)) {nbMenu = 31;}
            if ((mouse_y>178)&&(mouse_y<260)&&(mouse_b&1)) {nbMenu = 32;}

        }

        blit(buffer,buffer2,0,0,0,0,1280,720);
        blit(buffer2,screen,0,0,0,0,1280,720);
        show_mouse(screen);

        }


        if (nbMenu == 69){       //Juste pour mettre le code d'exemple en commentaire et economiser de la place
//    /**Menu de choix - do while*/
//    do
//    {
//        printf("Introduire votre choix :\n");
//        printf("- %d Saisie au clavier de la liste de produits\n",SAISIE_TAB_LIST_CLAVIER);
//        printf("- %d Chargement � partir d'un fichier de la liste des produits\n", LOAD_TAB_FROM_FILE );
//        printf("- %d Chargement � partir d'une base de donn�e\n", LOAD_TAB_FROM_DB );
//        printf("- %d Affichage de la liste des produits\n", AFFICHE_TAB_PRO);
//        printf("- %d Tri par le prix de la liste de produits\n",TRI_PROD_PRIX);
//        printf("- %d Tri par le nom de la liste de produits \n", TRI_PROD_NOM);
//        printf("- %d Insertion d'un nouveau produit � la liste des produit\n", INSERT_NEW_PROD);
//        printf("- %d Recherche d'un produit dans la liste des produits\n", FIND_PROD_IN_TAB);
//        printf(" -%d Enregistrement la la liste des produit dans un fichier\n",SAVE_TAB_IN_FILE);
//        printf(" -%d Enregistrement la la liste des produit dans une Base de Donn�e\n",SAVE_TAB_IN_DB);
//        printf(" -%d Quitter l'application \n ==> ",QUITTER);
//        scanf("%d",&CHOIX);
//
//        /**Switch des diff�rents cas d'execution selon le choix introduit par l'utilisateur */
//        switch(CHOIX)
//        {
//        case (SAISIE_TAB_LIST_CLAVIER):
//            do
//            {
//                printf("inroduire N:");
//                scanf("%d",&N);
//            }
//            while(N<=0||N>MAX_SIZE_TAB);
//            saisie_liste_produit(N, tabProd);
//            break;
//        case(LOAD_TAB_FROM_FILE):
//            printf("Saisir le nom du fichier : ");
//            scanf("%s",nom_file_to_load);
//            load_liste_produit_from_file(&N,tabProd,nom_file_to_load);
//            break;
//        case(LOAD_TAB_FROM_DB):
//            printf("Saisir le nom de la BD: ");
//            scanf("%s",nom_bd_to_load);
//            mysql_init(&mysql);
//            load_liste_produit_from_DB(&N,tabProd,nom_bd_to_load,&mysql);
//            affiche_liste_produit(N,tabProd);
//            DBOPEN = 1;
//            break;
//        case(AFFICHE_TAB_PRO):
//            affiche_liste_produit(N,tabProd);
//            break;
//        case(TRI_PROD_PRIX):
//            tri_liste_produit_prix(N,tabProd);
//            break;
//        case(TRI_PROD_NOM):    //TODO
//            tri_liste_produit_nom(N, tabProd);
//            break;
//        case(INSERT_NEW_PROD):
//            p = saise_new_prod();
//            if(insert_nouveau_produit(N,tabProd,p))
//            {
//                N++;
//            }
//            break;
//        case(FIND_PROD_IN_TAB):    //TODO
//            p = saise_new_prod();
//            if(recherche_produit_into_list_produit(N, tabProd,p)==-1)
//            {
//                printf("produit [%s|%f] non trouve !! \n",p.nom,p.prix);
//            }
//            else
//            {
//                printf("produit [%s|%f] trouve. \n",p.nom,p.prix);
//            }
//            break;
//        case(SAVE_TAB_IN_FILE):
//            printf("Saisir le nom du fichier : ");
//            scanf("%s",nom_file_to_save);
//            save_liste_produit_into_file(N,tabProd,nom_file_to_save);
//            break;
//        case(SAVE_TAB_IN_DB):
//            printf("Saisir le nom du fichier : ");
//            scanf("%s",nom_bd_to_save);
//            save_liste_produit_into_DB(N,tabProd,nom_bd_to_save);
//            break;
//
//        case(QUITTER):
//            printf("Au revoir !!!");
//            if(DBOPEN==1)
//            {
//                //Fermeture de MySQL
//                mysql_close(&mysql);
//
//            }
//            break;
//        default:
//            printf("ERROR !!");
//            break;
//        }
//    }
//    while(CHOIX!=QUITTER);
        }
}END_OF_MAIN();
