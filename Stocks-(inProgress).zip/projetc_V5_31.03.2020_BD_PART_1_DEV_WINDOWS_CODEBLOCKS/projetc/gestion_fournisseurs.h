#ifndef _gestion_fournisseurs_h
#define _gestion_fournisseurs_h


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SIZE_TAB_FOURNISSEUR 100

struct Adresse{
int num;
char nomrue[30];
char nomville[30];
int codePostal;
char nomPays[30];
};
typedef struct Adresse Adr;

struct Fournisseur{
    //Fournisseur
    int code;
    Adr adr[50];
    long tel;
};
typedef struct Fournisseur Fourni;

struct Date{
    //Date
    int jour;
    int mois;
    int annee;
}; typedef struct Date date;


void saisie_liste_fournisseur(int nb, Fourni TABFOURNISSEUR[]);
void affiche_liste_fournisseur(int nb, Fourni TABFOURNISSEUR[]);
void tri_liste_code_fournisseur(int nb, Fourni TABFOURNISSEUR[]);
void tri_liste_adr_fournisseur(int nb, Fourni TABFOURNISSEUR[]);
int rechercher_fournisseur_in_tab(int nb, Fourni TABFOURNISSEUR[], Fourni fourniToFind);
int insert_nouveau_fournisseur(int nb, Fourni TABFOURNISSEUR[], Fourni fourniToFind);
void load_liste_fournisseurs_from_file(int* nb, Fourni TABFOURNISSEUR[], char* file_path);
void save_liste_fournisseurs_into_file(int nb, Fourni TABFOURNISSEUR[], char* file_path);
void affiche_listefournisseurs_into_file(Fourni TABFOURNISSEUR[], char* file_path);
void save_liste_fournisseurs_into_bdd(int* nb, Fourni TABFOURNISSEUR[], char* file_path);
void affiche_liste_fournisseurs_into_bdd(Fourni TABFOURNISSEUR[], char* file_path);
void  saisie_date(date * date_a_saisie);
void affiche_date(date d);

#endif
