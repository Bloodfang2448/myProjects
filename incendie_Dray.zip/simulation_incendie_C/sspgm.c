#include "header.h"

int couleur_aleatoire()
{
    int categ = (rand()%3)+1;

    return categ;

}

void terrain_aleatoire(t_parcelle T1 [L][C])
{
    int i=0,j=0;

    for (i=0; i<L; i++)
    {
        for (j=0; j<C; j++)
        {
            T1[i][j].category = couleur_aleatoire();
            T1[i][j].x = 30*j;
            T1[i][j].y = 20*i;
        }
    }
}

void burn_baby_burn(int x, int y, t_parcelle T1 [L][C]) //Disco Infernoooo~~
{
    int i=0,j=0;

    for (i=0; i<L; i++)
    {
        for (j=0; j<C; j++)
        {
            if((x> T1 [i][j].x)&&(x< (T1 [i][j].x)+30)&&(y> T1 [i][j].y)&&(y< (T1 [i][j].y)+20)&&(T1[i][j].category==2))
            {
                T1[i][j].category=4;
            }
        }
    }
}

void next_turn(t_parcelle T1 [L][C], int T2 [L][C])
{
    int i=0,j=0;

    for (i=0; i<L; i++)
    {
        for (j=0; j<C; j++)
        {
            if (T1 [i][j].category == 4)
            {
                T2 [i][j] = 5;
            }
            else if (T1 [i][j].category == 5)
            {
                T2 [i][j] = 6;
            }
            else if ((T1 [i][j].category == 2)&&((T1 [i-1][j-1].category == 4)||(T1 [i-1][j].category == 4)||(T1 [i-1][j+1].category == 4)||(T1 [i][j-1].category == 4)||(T1 [i][j+1].category == 4)||(T1 [i+1][j-1].category == 4)||(T1 [i+1][j].category == 4)||(T1 [i+1][j+1].category == 4)))
            {
                T2 [i][j] = 4;
            }
            else
            {
                T2 [i][j] = T1 [i][j].category;
            }
        }
    }

    for (i=0; i<L; i++)
    {
        for(j=0; j<C; j++)
        {
            T1[i][j].category = T2[i][j];
        }
    }
}
