#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

#define L  40
#define C  60

#include <allegro.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct parcelle
{

    int x;    //pour le sprite
    int y;    //pour le sprite
    int category;   // 1-terre, 2-arbre, 3-eau, 4-feu, 5-cendres, 6-cendres eteintes

} t_parcelle;

typedef struct terrain
{

    t_parcelle T1 [L][C];
    int T2 [L][C];

} t_terrain;

int couleur_aleatoire();
void terrain_aleatoire(t_parcelle T1 [L][C]);
void burn_baby_burn(int x, int y, t_parcelle T1 [L][C]); //Disco Infernoooo~~
void next_turn(t_parcelle T1 [L][C], int T2 [L][C]);


#endif // HEADER_H_INCLUDED
