#include "header.h"

int main()
{
    t_terrain ground;
    int i=0, j=0, k=0;
    allegro_init();
    install_keyboard();
    install_mouse();
    show_mouse(screen);
    srand(time(NULL));
    install_sound(DIGI_AUTODETECT, MIDI_AUTODETECT, NULL);
    set_color_depth(desktop_color_depth());
    if (set_gfx_mode(GFX_AUTODETECT_WINDOWED, 1800, 800, 0, 0) != 0)
    {
        allegro_message("probleme GFX mode");
        allegro_exit();
        exit(EXIT_FAILURE);
    }

    BITMAP* tree = load_bitmap("sprites/tree.bmp", NULL);
    BITMAP* water = load_bitmap("sprites/water.bmp", NULL);
    BITMAP* fire = load_bitmap("sprites/fire.bmp", NULL);
    BITMAP* earth = load_bitmap("sprites/earth.bmp", NULL);
    BITMAP* redstone = load_bitmap("sprites/redstone.bmp", NULL);
    BITMAP* ashes = load_bitmap("sprites/ashes.bmp", NULL);
    BITMAP* background = create_bitmap(1800,800);
    BITMAP* buffer = create_bitmap(1800,800);

    for (j=0; j<C; j++) //Background plein de earth pour pas que les transparences soient moches
    {
        for (k=0; k<L; k++)
        {
            blit(earth,background,0,0,j*30,k*20,30,20);
        }
    }

    terrain_aleatoire(ground.T1);

    while(!key[KEY_ESC])
    {
        if (mouse_b&1)
        {
            burn_baby_burn(mouse_x,mouse_y,ground.T1);
        }
        if (i%50==0)
        {
            next_turn(ground.T1,ground.T2);
        }

        rest(50);

        blit(background,buffer,0,0,0,0,1800,800);

        for (j=0; j<L; j++)
        {
            for (k=0; k<C; k++)
            {
                switch (ground.T1[j][k].category)
                {
                    case 1: draw_sprite(buffer,earth,ground.T1[j][k].x,ground.T1[j][k].y); break;
                    case 2: draw_sprite(buffer,tree,ground.T1[j][k].x,ground.T1[j][k].y); break;
                    case 3: draw_sprite(buffer,water,ground.T1[j][k].x,ground.T1[j][k].y); break;
                    case 4: draw_sprite(buffer,fire,ground.T1[j][k].x,ground.T1[j][k].y); break;
                    case 5: draw_sprite(buffer,redstone,ground.T1[j][k].x,ground.T1[j][k].y); break;
                    case 6: draw_sprite(buffer,ashes,ground.T1[j][k].x,ground.T1[j][k].y); break;
                }
            }
        }
        blit(buffer,screen,0,0,0,0,1800,800);
        show_mouse(screen);
        i++;
    }

    return 0;
}END_OF_MAIN();
